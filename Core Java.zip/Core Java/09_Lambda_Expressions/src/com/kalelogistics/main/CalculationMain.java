package com.kalelogistics.main;

import java.util.Scanner;

import com.kalelogistics.main.domain.ArithmaticOperation;

public class CalculationMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		ArithmaticOperation arithmaticOperation = null;
		double number1, number2;
		System.out.println("Enter number 1");
		number1 = scanner.nextDouble();
		System.out.println("Enter number 2");
		number2 = scanner.nextDouble();

		System.out.println("1. Addition");
		System.out.println("2. Subtraction");
		System.out.println("3. Multiplication");
		System.out.println("4. Division");
		System.out.println("Enter your choice");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
//			arithmaticOperation = (double n1, double n2) -> {
//				return n1 + n2;
//			};

			arithmaticOperation = (n1, n2) -> n1 + n2;
			break;
		case 2:
//			arithmaticOperation = (double n1, double n2) -> {
//				return n1 - n2;
//			};
			arithmaticOperation = (n1, n2) -> n1 - n2;
			break;
		case 3:
//			arithmaticOperation = (double n1, double n2) -> {
//				return n1 * n2;
//			};
			arithmaticOperation = (n1, n2) -> n1 * n2;
			break;
		case 4:
//			arithmaticOperation = (double n1, double n2) -> {
//				return n1 / n2;
//			};
			arithmaticOperation = (n1, n2) -> n1 / n2;
			break;
		default:
			System.out.println("Invalid Choice");
			break;
		}

		if (arithmaticOperation != null)
			System.out.println("Result = " + arithmaticOperation.doCalculation(number1, number2));

	}
}
