package com.kalelogistics.main;

import java.util.Scanner;

import com.kalelogistics.main.domain.GoodAfternoonGreetings;
import com.kalelogistics.main.domain.GoodMorningGreetings;
import com.kalelogistics.main.domain.Greetings;

public class GreetingsMain {
	public static void main(String[] args) {
		Greetings greetings = null;
		Scanner scanner = new Scanner(System.in);

		System.out.println("Menu");
		System.out.println("1. Good Morning");
		System.out.println("2. Good Afternoon");
		System.out.println("3. Good Evening");
		System.out.println("4. Good Night");
		System.out.println("Make a choice");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			greetings = new GoodMorningGreetings();
			break;
		case 2:
			greetings = new GoodAfternoonGreetings();
			break;
		case 3:
//			greetings = new Greetings() {
//				@Override
//				public void greet() {
//					System.out.println("Good Evening");
//				}
//			};
			
			
//			greetings = () -> System.out.println("Good Evening");
			
			greetings = () -> { 
					System.out.println("Good Evening");
			};
			
			break;
		case 4:
//			greetings = new Greetings() {
//				@Override
//				public void greet() {
//					System.out.println("Good Night");
//				}
//			};
			
			greetings = () -> System.out.println("Good Night");
			
			break;
		default:
			System.out.println("Invalid Choice");
			break;
		}

		if (greetings != null)
			greetings.greet();

		scanner.close();

	}
}
