package com.kalelogistics.main;

import com.kalelogistics.main.domain.GoodMorningGreetings;
import com.kalelogistics.main.domain.Greetings;

public class TestingMain {
	public static void main(String[] args) {
		System.out.println("main start");

		Greetings greetings = null;

		greetings = new GoodMorningGreetings();
		myFunction(greetings); // Good Morning

		greetings = () -> System.out.println("Good Night");
		myFunction(greetings); // Good Night

		myFunction(() -> System.out.println("Good Day"));

		System.out.println("main end");
	}

	public static void myFunction(Greetings greetings) {
		greetings.greet();
	}
}
