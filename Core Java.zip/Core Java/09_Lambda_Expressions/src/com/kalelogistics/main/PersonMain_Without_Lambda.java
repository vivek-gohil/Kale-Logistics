package com.kalelogistics.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.kalelogistics.main.domain.Person;

public class PersonMain_Without_Lambda {
	public static void main(String[] args) {
		Person person1 = new Person("Vivek", "Gohil", 35);
		Person person2 = new Person("Trupti", "Acharekar", 33);
		Person person3 = new Person("Gurubux", "Gill", 30);
		Person person4 = new Person("Samarth", "Patil", 10);

		List<Person> people = new ArrayList<Person>();
		people.add(person1);
		people.add(person2);
		people.add(person3);
		people.add(person4);

		// No lambda expressions

		// Sort the list by last name
		// Collections.sort(people);

//		Comparator<Person> compareByLastName = new Comparator<Person>() {
//			@Override
//			public int compare(Person p1, Person p2) {
//				return p1.getLastName().compareTo(p2.getLastName());
//			}
//		};

		Comparator<Person> compareByLastName = (p1, p2) -> p1.getLastName().compareTo(p2.getLastName());
		Collections.sort(people, compareByLastName);

		// Create method to print all person from list - printAll(...)
		printAll(people);
		System.out.println();
		// Create method to print all person that have last name beginning with G -
		// printLastNameBeginningWithG(...)
		printLastNameBeginningWith(people, "G");
		System.out.println();
		// Create method to print all person that have last name ending with l -
		// printLastNameEndsWithL(...)
		printLastNameEndsWith(people, "l");
	}

	public static void printAll(List<Person> people) {
		for (Person person : people) {
			System.out.println(person);
		}
	}

	public static void printLastNameBeginningWith(List<Person> people, String alphbet) {
		for (Person person : people) {
			if (person.getLastName().startsWith(alphbet))
				System.out.println(person);
		}
	}

	public static void printLastNameEndsWith(List<Person> people, String alphbet) {
		for (Person person : people) {
			if (person.getLastName().endsWith(alphbet))
				System.out.println(person);
		}
	}
}
