package com.kalelogistics.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

import com.kalelogistics.main.domain.Person;

public class PersonMainWithLambda {
	public static void main(String[] args) {
		Person person1 = new Person("Vivek", "Gohil", 35);
		Person person2 = new Person("Trupti", "Acharekar", 33);
		Person person3 = new Person("Gurubux", "Gill", 30);
		Person person4 = new Person("Samarth", "Patil", 10);

		List<Person> people = new ArrayList<Person>();
		people.add(person1);
		people.add(person2);
		people.add(person3);
		people.add(person4);

		Comparator<Person> compareByLastName = (p1, p2) -> p1.getLastName().compareTo(p2.getLastName());
		Collections.sort(people, compareByLastName);

		Predicate<Person> predicate = null;
		Consumer<Person> consumer = null;
//		predicate = new Predicate<Person>() {
//			@Override
//			public boolean test(Person t) {
//				return true;
//			}
//		};
//		consumer = new Consumer<Person>() {
//
//			@Override
//			public void accept(Person p) {
//				System.out.println(p);
//			}
//		};
//
//		printConditionally(people, predicate, consumer);

		printConditionally(people, (p) -> true, (p) -> System.out.println(p));

		System.out.println();

//		predicate = new Predicate<Person>() {
//
//			@Override
//			public boolean test(Person t) {
//				return t.getLastName().startsWith("G");
//			}
//		};
//
//		consumer = new Consumer<Person>() {
//			@Override
//			public void accept(Person p) {
//				System.out.println(p.getFirstName() + " " + p.getLastName());
//			}
//		};
//
//		printConditionally(people, predicate, consumer);

		printConditionally(people, (p) -> p.getLastName().startsWith("G"),
				(p) -> System.out.println(p.getFirstName() + " " + p.getLastName()));

		System.out.println();

//		predicate = new Predicate<Person>() {
//
//			@Override
//			public boolean test(Person t) {
//				return t.getLastName().endsWith("l");
//			}
//		};
//
//		consumer = new Consumer<Person>() {
//			@Override
//			public void accept(Person p) {
//				System.out.println(p.getLastName() + " " + p.getAge());
//			}
//		};
//
//		printConditionally(people, predicate, consumer);

		// last name and age
		printConditionally(people, (p) -> p.getLastName().endsWith("l"),
				(p) -> System.out.println(p.getLastName() + " " + p.getAge()));
	}

	public static void printConditionally(List<Person> people, Predicate<Person> predicate, Consumer<Person> consumer) {
		for (Person person : people) {
			if (predicate.test(person))
				consumer.accept(person);
		}
	}
}
