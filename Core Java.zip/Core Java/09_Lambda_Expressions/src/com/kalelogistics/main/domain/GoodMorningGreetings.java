package com.kalelogistics.main.domain;

//To Greet Good Morning
public class GoodMorningGreetings implements Greetings {
	@Override
	public void greet() {
		System.out.println("Good Morning!");
	}
}
