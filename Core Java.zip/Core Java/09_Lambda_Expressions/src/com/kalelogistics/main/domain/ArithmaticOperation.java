package com.kalelogistics.main.domain;

public interface ArithmaticOperation {
	double doCalculation(double number1, double number2);
}
