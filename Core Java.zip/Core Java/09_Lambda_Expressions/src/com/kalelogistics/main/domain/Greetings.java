package com.kalelogistics.main.domain;
//Functional Interface - contains only one method 
public interface Greetings {
	void greet();
}
