package com.kalelogistics.main.domain;

//To Greet Good Afternoon
public class GoodAfternoonGreetings implements Greetings {
	@Override
	public void greet() {
		System.out.println("Good Afternoon!");
	}
}
 