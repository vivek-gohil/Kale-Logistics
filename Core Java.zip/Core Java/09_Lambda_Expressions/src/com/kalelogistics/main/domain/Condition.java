package com.kalelogistics.main.domain;
//Functional Interface
public interface Condition {
	public boolean test(Person person);
}
