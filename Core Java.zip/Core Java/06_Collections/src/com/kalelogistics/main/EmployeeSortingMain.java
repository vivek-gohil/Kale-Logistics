package com.kalelogistics.main;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.kalelogistics.main.domain.Employee;
import com.kalelogistics.main.domain.SortEmployeeByName;
import com.kalelogistics.main.domain.SortingEmployeeBySalary;

public class EmployeeSortingMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		Employee employee1 = new Employee(101, "Bhavya", 900000);
		Employee employee2 = new Employee(102, "Dipak", 800000);
		Employee employee3 = new Employee(103, "Suman", 700000);
		Employee employee4 = new Employee(104, "Atharva", 600000);

		Set<Employee> employeeSet = new TreeSet<Employee>();

		employeeSet.add(employee4);
		employeeSet.add(employee3);
		employeeSet.add(employee2);
		employeeSet.add(employee1);

		for (Employee employee : employeeSet) {
			System.out.println(employee);
		}

		System.out.println("1. Add New Employee");
		System.out.println("2. Print All Employee");
		System.out.println("3. Search Employee By Employee Id");
		System.out.println("4. Remove/Delete Employee By Employee Id");
		System.out.println("5. Sort Employees By EmployeeId - Default ");
		System.out.println("6. Sort Employees By Name");
		System.out.println("7. Sort Employees By Salary");
		System.out.println("Enter your choice");

		int choice = scanner.nextInt();

		switch (choice) {
		case 1:
			System.out.println("Enter employeeeId");
			int employeeId = scanner.nextInt();
			System.out.println("Enter name");
			String name = scanner.next();
			System.out.println("Enter salary");
			double salary = scanner.nextDouble();

			Employee e = new Employee(employeeId, name, salary);
			if (employeeSet.add(e))
				System.out.println("Employee added successfully");
			else
				System.out.println("Failed to add employee");

		case 2:
			for (Employee employee : employeeSet) {
				System.out.println(employee);
			}
			break;
		case 3:
			System.out.println("Enter employeeeId");
			employeeId = scanner.nextInt();
			for (Employee employee : employeeSet) {
				if (employee.getEmployeeId() == employeeId)
					System.out.println(employee);
			}
			break;
		case 4:
			System.out.println("Enter employeeeId");
			employeeId = scanner.nextInt();
			Iterator<Employee> it = employeeSet.iterator();
			while (it.hasNext()) {
				Employee emp = (Employee) it.next();
				if (emp.getEmployeeId() == employeeId) {
					it.remove();
				}

			}
			break;
		case 5:
			System.out.println();
			for (Employee employee : employeeSet) {
				System.out.println(employee);
			}
			System.out.println();
			break;
		case 6:
			SortEmployeeByName byName = new SortEmployeeByName();
			employeeSet = new TreeSet<Employee>(byName);
			employeeSet.add(employee4);
			employeeSet.add(employee3);
			employeeSet.add(employee2);
			employeeSet.add(employee1);

			for (Employee employee : employeeSet) {
				System.out.println(employee);
			}
			break;
		case 7:

			SortingEmployeeBySalary bySalary = new SortingEmployeeBySalary();
			employeeSet = new TreeSet<Employee>(bySalary);
			employeeSet.add(employee4);
			employeeSet.add(employee3);
			employeeSet.add(employee2);
			employeeSet.add(employee1);

			for (Employee employee : employeeSet) {
				System.out.println(employee);
			}

			break;
		default:
			System.out.println("Invalid Choice");
			break;
		}

		scanner.close();
	}
}
