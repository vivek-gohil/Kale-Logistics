package com.kalelogistics.main;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.kalelogistics.main.domain.Employee;

public class CollectionsMain {
	public static void main(String[] args) {
		// Collections - Dynamic In Size
		// List(interface) and ArrayList(Class)

		// Creating object of ArrayList class - General Declaration
		// ArrayList<String> arrayList = new ArrayList<String>();

		// Using Polymorphism - recommended
		// List = Allow Duplicate Objects
//		List<String> list = new ArrayList<String>();
//		System.out.println("size :: " + list.size());
//		list.add("Suman");
//		list.add("Atharva");
//		list.add("Harshit");
//		list.add("Atharva");
//		list.add("Shruti");
//		list.add("Harshit");
//		list.add("Shruti");
//
//		// Display all
//		System.out.println(list);
//
//		// Using index location
//		System.out.println(list.get(2));
//
//		System.out.println("size :: " + list.size());
//		System.out.println("-----------Remove------------");
//		System.out.println(list.remove(1));
//		System.out.println(list.remove("Atharva"));
//		System.out.println(list);
//		System.out.println("size :: " + list.size());
//
//		System.out.println("-----------------------------------");
////		for (String s : list) {
////			if (s.equals("Atharva")) {
////				list.remove(s);
////			}
////		}
//
//		Iterator<String> it = list.iterator();
//		while (it.hasNext()) {
//			String s = (String) it.next();
//			if (s.equals("Atharva")) {
//				it.remove();
//			}
//
//		}
//
//		List<Employee> employeeList = new ArrayList<Employee>();
//
//		Employee employee1 = new Employee(101, "Bhavya", 900000);
//		Employee employee2 = new Employee(102, "Dipak", 900000);
//		Employee employee3 = new Employee(103, "Suman", 900000);
//		Employee employee4 = new Employee(104, "Atharva", 900000);
//
//		employeeList.add(employee1);
//		employeeList.add(employee2);
//		employeeList.add(employee3);
//		employeeList.add(employee4);
//
//		System.out.println(employeeList);
//
//		System.out.println("-".repeat(80));
//		for (Employee employee : employeeList) {
//			System.out.println(employee);
//		}

//		System.out.println("-".repeat(80));
//		System.out.println("Set");
//		System.out.println("-".repeat(80));
//
//		// Polymorphism
//		Set<String> nameSet = new HashSet<String>();
//		nameSet.add("Suman");
//		nameSet.add("Atharva");
//		nameSet.add("Harshit");
//		nameSet.add("Atharva");
//		nameSet.add("Shruti");
//		nameSet.add("Harshit");
//		nameSet.add("Shruti");
//
//		System.out.println(nameSet);
//
//		nameSet.remove("Harshit");
//
//		System.out.println(nameSet);
//		Employee employee1 = new Employee(101, "Bhavya", 900000);
//		Employee employee2 = new Employee(102, "Dipak", 900000);
//		Employee employee3 = new Employee(103, "Suman", 900000);
//		Employee employee4 = new Employee(104, "Atharva", 900000);
//		Employee employee5 = new Employee(101, "Bhavya", 900000);
//		Employee employee6 = new Employee(102, "Dipak", 900000);
//		Employee employee7 = new Employee(103, "Suman", 900000);
//		Employee employee8 = new Employee(104, "Atharva", 900000);
//
//		Set<Employee> employeeSet = new HashSet<Employee>();
//		System.out.println(employee1.hashCode());
//		System.out.println(employeeSet.add(employee1));
//		System.out.println(employee2.hashCode());
//		System.out.println(employeeSet.add(employee2));
//		System.out.println(employee3.hashCode());
//		System.out.println(employeeSet.add(employee3));
//		System.out.println(employee4.hashCode());
//		System.out.println(employeeSet.add(employee4));
//		System.out.println(employee5.hashCode());
//		System.out.println(employeeSet.add(employee5));
//		System.out.println(employee6.hashCode());
//		System.out.println(employeeSet.add(employee6));
//		System.out.println(employee7.hashCode());
//		System.out.println(employeeSet.add(employee7));
//		System.out.println(employee8.hashCode());
//		System.out.println(employeeSet.add(employee8));
//
//		// System.out.println(employeeSet);
//		for (Employee employee : employeeSet) {
//			System.out.println(employee);
//		}

//		System.out.println("-".repeat(80));
//		System.out.println("TreeSet");
//		System.out.println("-".repeat(80));
//
//		Set<String> nameSet = new TreeSet<String>();
//		nameSet.add("Suman");
//		nameSet.add("Atharva");
//		nameSet.add("Harshit");
//		nameSet.add("Atharva");
//		nameSet.add("Shruti");
//		nameSet.add("Harshit");
//		nameSet.add("Shruti");
//
//		System.out.println(nameSet);
//
//		Employee employee1 = new Employee(101, "Bhavya", 900000);
//		Employee employee2 = new Employee(102, "Dipak", 800000);
//		Employee employee3 = new Employee(103, "Suman", 700000);
//		Employee employee4 = new Employee(104, "Atharva", 600000);
//		Employee employee5 = new Employee(101, "Bhavya", 900000);
//		Employee employee6 = new Employee(102, "Dipak", 800000);
//		Employee employee7 = new Employee(103, "Suman", 700000);
//		Employee employee8 = new Employee(104, "Atharva", 600000);
//
//		Set<Employee> employeeSet = new TreeSet<Employee>();
//		employeeSet.add(employee8);
//		employeeSet.add(employee7);
//		employeeSet.add(employee6);
//		employeeSet.add(employee5);
//		employeeSet.add(employee4);
//		employeeSet.add(employee3);
//		employeeSet.add(employee2);
//		employeeSet.add(employee1);
//
//		for (Employee employee : employeeSet) {
//			System.out.println(employee);
//		}

		System.out.println("-".repeat(80));
		System.out.println("Map");
		System.out.println("-".repeat(80));

		Map<Integer, String> myMap = new HashMap<Integer, String>();
		myMap.put(101, "Dipak");
		myMap.put(102, "Suman");
		myMap.put(11, "Dipak");
		myMap.put(1019, "Dipak");

		System.out.println(myMap);

		Map<Integer, String> sortedMyMap = new TreeMap<Integer, String>();
		sortedMyMap.put(101, "Dipak");
		sortedMyMap.put(102, "Suman");
		sortedMyMap.put(11, "Dipak");
		sortedMyMap.put(1019, "Dipak");

		System.out.println(sortedMyMap);

	}

}
