package com.kalelogistics.main;

import com.kalelogistics.main.domain.Spotify;
import com.kalelogistics.main.domain.WithAd;
import com.kalelogistics.main.domain.WithoutAd;

public class EndUserMobile {
	public static void main(String[] args) {
		//For free user
		WithAd ad = new Spotify();
		ad.playWIthAd();
		
		//For paid users
		WithoutAd withoutAd = new Spotify();
		withoutAd.playWithoutAd();
	}
}
