package com.kalelogistics.main;

import com.kalelogistics.main.domain.Greetings;
import com.kalelogistics.main.domain.MyInterface;

public class InterfaceMain {
	public static void main(String[] args) {
		MyInterface myInterface = new Greetings();
		myInterface.greet();
		myInterface.show();
	}

}
