package com.kalelogistics.main.domain;

public interface WithAd {
	void playWIthAd();
}
