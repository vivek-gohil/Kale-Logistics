package com.kalelogistics.main.domain;

public class Greetings implements MyInterface {

	@Override
	public void greet() {
		System.out.println("Good Morning");

	}

	@Override
	public void show() {
		System.out.println("Interfaces are simple");
	}

}
