package com.kalelogistics.main.domain;

public interface WithoutAd {
	void playWithoutAd();
}
