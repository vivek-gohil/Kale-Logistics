package com.kalelogistics.main.domain;

public class YourClass extends MyClass {
//	@Override
//	public void print() {
//		System.out.println("Hello");
//	}

	@Override
	public void display() {
		System.out.println("Good Morning");
	}
}
