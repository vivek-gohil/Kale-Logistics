package com.kalelogistics.main.domain;

public class Spotify implements WithAd, WithoutAd {

	@Override
	public void playWithoutAd() {
		System.out.println("Playing without Ad");

	}

	@Override
	public void playWIthAd() {
		System.out.println("Playing with Ad");

	}

}
