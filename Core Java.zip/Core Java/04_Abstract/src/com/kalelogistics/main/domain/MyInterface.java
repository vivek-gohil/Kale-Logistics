package com.kalelogistics.main.domain;

//Pure abstract in nature
public interface MyInterface {
	void greet(); // public abstract void greet();

	void show(); // public abstract void show();
}
