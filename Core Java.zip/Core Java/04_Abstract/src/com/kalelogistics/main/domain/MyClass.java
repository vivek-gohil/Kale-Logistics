package com.kalelogistics.main.domain;

public abstract class MyClass {
	public void print() {
		System.out.println("Hi");
	}
	public abstract void display();
}
