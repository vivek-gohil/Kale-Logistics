package com.kalelogistics.main;

import com.kalelogistics.main.domain.MyClass;
import com.kalelogistics.main.domain.YourClass;

public class AbstractMain {
	public static void main(String[] args) {
		// Try to create object of abstract class
		// MyClass myClass = new MyClass(); //Cannot create object of abstract class

		MyClass myclass = new YourClass();
		myclass.print();
		myclass.display();
	}
}
