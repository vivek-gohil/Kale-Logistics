package com.kalelogistics.main.domain;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Calculations {
	private int number1, number2, result;

	public void accept() {
		System.out.println("accept() start");
		Scanner scanner = new Scanner(System.in);
		try {
			System.out.println("Enter first number");
			number1 = scanner.nextInt();
			System.out.println("Enter second number");
			number2 = scanner.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("Exception in accept()");
			System.out.println("Invalid Input From User");
			if (e.getMessage() != null)
				System.out.println(e.getMessage());
		} finally {
			System.out.println("closing scanner");
			scanner.close();
		}
		System.out.println("accept() end");
	}

	public void calculate() {
		System.out.println("calculate() start");
		result = number1 + number2;
		System.out.println("calculate() end");
	}

	public void display() {
		System.out.println("display() start");
		System.out.println("Result = " + result);
		System.out.println("display() end");
	}

}
