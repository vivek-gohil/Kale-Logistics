package com.kalelogistics.main;

import com.kalelogistics.main.domain.Employee;
import com.kalelogistics.main.exceptions.InvalidEmployeeSalaryException;

public class EmployeeMain {
	public static void main(String[] args) {
		try {
			Employee employee = new Employee(101, "Test", 1000);
			System.out.println(employee);
		} catch (InvalidEmployeeSalaryException e) {
			System.out.println(e.getMessage());
		}
	}
}
