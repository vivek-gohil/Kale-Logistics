package com.kalelogistics.main;

import com.kalelogistics.main.domain.Calculations;

public class CalculationsMain {

	public static void main(String[] args) {
		System.out.println("main() start");

		Calculations calculations = new Calculations();
		calculations.accept();
		System.out.println("-".repeat(80));
		calculations.calculate();
		System.out.println("-".repeat(80));
		calculations.display();
		
		System.out.println("main() end");
	}

}
