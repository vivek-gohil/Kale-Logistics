package com.kalelogistics.main.exceptions;

//Extending Exception class will create checked exception
//Extending RuntimeException class will create unchecked exception
public class InvalidEmployeeSalaryException extends RuntimeException {
	public InvalidEmployeeSalaryException() {
		System.out.println("InvalidEmployeeSalaryException");
	}

	@Override
	public String getMessage() {
		return "Employee salary must be > 0";
	}
}
