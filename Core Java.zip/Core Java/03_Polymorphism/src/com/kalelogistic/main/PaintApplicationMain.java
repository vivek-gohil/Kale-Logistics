package com.kalelogistic.main;

import java.util.Scanner;

import com.kalelogistic.domain.Circle;
import com.kalelogistic.domain.Line;
import com.kalelogistic.domain.Shapes;
import com.kalelogistic.domain.Triangle;

public class PaintApplicationMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		Shapes shapes = null;
		System.out.println("1. Circle");
		System.out.println("2. Triangle");
		System.out.println("3. Line");
		System.out.println("Select shape");
		int choice = scanner.nextInt();
		
		switch (choice) {
		case 1:
			shapes = new Circle();
			break;
		case 2:
			shapes = new Triangle();
			break;
		case 3:
			shapes = new Line();
			break;
		default:
			System.out.println("Invalid Choice");
			break;
		}
		
		if(choice >=1 && choice <= 3 && shapes != null) {
			shapes.draw(); // Polymorphism = Runtime
		}
		
		scanner.close();
	}
}
