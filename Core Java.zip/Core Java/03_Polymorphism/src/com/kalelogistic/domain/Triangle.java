package com.kalelogistic.domain;

public class Triangle extends Shapes {
	@Override
	public void draw() {
		System.out.println("Drawing Triangle");
	}
}
