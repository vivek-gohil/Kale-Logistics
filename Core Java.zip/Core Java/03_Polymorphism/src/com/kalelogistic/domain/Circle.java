package com.kalelogistic.domain;

public class Circle extends Shapes {
	@Override
	public void draw() {
		System.out.println("Drawing Circle");
	}
}
