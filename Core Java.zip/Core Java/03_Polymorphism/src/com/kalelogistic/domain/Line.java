package com.kalelogistic.domain;

public class Line extends Shapes {
	@Override
	public void draw() {
		System.out.println("Drawing Line");
	}
}
