package com.kalelogistic.domain;

public abstract class Shapes {
//	public void draw() {
//		System.out.println("Drwaing Shapes");
//	}

	public abstract void draw();
}
