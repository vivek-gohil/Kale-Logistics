package com.kalelogistics.main;

import java.util.Scanner;

import com.kalelogistics.main.domain.Account;

public class AccountMainV2 {
	public static void main(String[] args) {

		// accept input from user // Opens InputStream
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter account number");
		long accountNumber = scanner.nextLong();

		scanner.nextLine();
		
		System.out.println("Enter name");
		String name = scanner.nextLine();

		System.out.println("Enter balance");
		double balance = scanner.nextDouble();

		Account account = new Account(accountNumber, name, balance);

		System.out.println("Account Number = " + account.getAccountNumber());
		System.out.println("Name = " + account.getName());
		System.out.println("Balance = " + account.getBalance());

		scanner.close();

	}
}
