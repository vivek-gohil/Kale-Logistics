package com.kalelogistics.main.domain;

public class Account {
	
	private long accountNumber;
	private String name;
	private double balance;

	// Constructor - Called automatically at the time of object creation
	// Default Constructor
	public Account() {
		System.out.println("Account class object created");
		System.out.println("Account class default constructor called!!");
	}

	// Overloaded Constructor - Parameterized Constructor
	public Account(long accountNumber, String name, double balance) {
		this.accountNumber = accountNumber;
		this.name = name;
		this.balance = balance;

		System.out.println("Account class object created");
		System.out.println("Account class parameterized constrcutor called!!");
	}

	public boolean withdraw(double amount) {
		if (amount > 0 && amount <= balance) {
			balance -= amount;
			return true;
		}
		return false;
	}

	public boolean deposit(double amount) {
		if (amount > 0) {
			balance += amount;
			return true;
		}
		return false;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}                                                                                                                                                                                      
}
