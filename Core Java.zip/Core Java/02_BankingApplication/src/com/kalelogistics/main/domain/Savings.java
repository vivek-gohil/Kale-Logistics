package com.kalelogistics.main.domain;

//Savings is a Account - "is a" = inheritance
public class Savings extends Account {
	private double minimumBalance = 1500;
	private boolean isSalary;

	public Savings() {
		System.out.println("Savings class object created");
		System.out.println("Savings class default constructor called!!");
	}

	public Savings(long accountNumber, String name,double balance ,boolean isSalary) {
		super(accountNumber,name,balance);
		this.isSalary = isSalary;
		System.out.println("Savings class object created");
		System.out.println("Savings class parameterized constrcutor called!!");
	}

	// Override withdraw method of Account class -
	@Override
	public boolean withdraw(double amount) {
		// case 1 = savings account is salary account
		if (amount > 0 && isSalary && amount <= getBalance()) {
			setBalance(getBalance() - amount);
			return true;
		}

		// case 2 = savings account , maintain minimum balance
		if (amount > 0 && isSalary == false && getBalance() - amount >= minimumBalance) {
			setBalance(getBalance() - amount);
			return true;
		}

		return false;
	}

	// Override deposit method of Account class - not modifying the functionality
	@Override
	public boolean deposit(double amount) {
		return super.deposit(amount);
	}

	public double getMinimumBalance() {
		return minimumBalance;
	}

	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	public boolean isSalary() {
		return isSalary;
	}

	public void setSalary(boolean isSalary) {
		this.isSalary = isSalary;
	}

}
