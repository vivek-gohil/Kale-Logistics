package com.kalelogistics.main;

import java.util.Scanner;

import com.kalelogistics.main.domain.Account;
import com.kalelogistics.main.domain.Savings;

public class SavingsMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String continueChoice = "";

		System.out.println("Enter account number");
		long accountNumber = scanner.nextLong();

		scanner.nextLine();

		System.out.println("Enter name");
		String name = scanner.nextLine();

		System.out.println("Enter balance");
		double balance = scanner.nextDouble();

		System.out.println("Do you want to open salary account - true-false");
		boolean isSalary = scanner.nextBoolean();

		// Account account = new Account(accountNumber, name, balance);
		Savings savings = new Savings(accountNumber, name, balance, isSalary);

		System.out.println("Account Number = " + savings.getAccountNumber());
		System.out.println("Name = " + savings.getName());
		System.out.println("Balance = " + savings.getBalance());
		System.out.println();

		do {
			System.out.println("Menu");
			System.out.println("1. Withdraw");
			System.out.println("2. Deposit");
			System.out.println("3. Check Balance");
			System.out.println("Enter your choice");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter amount to withdraw");
				double amount = scanner.nextDouble();
				boolean status = savings.withdraw(amount);
				if (status) {
					System.out.println("Withdraw Transaction Successfull");
				} else {
					System.out.println("Withdraw Transaction Failed");
				}
				break;
			case 2:
				System.out.println("Enter amount to withdraw");
				amount = scanner.nextDouble();
				status = savings.deposit(amount);
				if (status) {
					System.out.println("Deposit Transaction Successfull");
				} else {
					System.out.println("Deposit Transaction Failed");
				}
				break;
			case 3:
				System.out.println("Balance = " + savings.getBalance());
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue?");
			continueChoice = scanner.next();
		} while (continueChoice.equals("yes"));
		System.out.println("Thank you");

		scanner.close();

	}

}
