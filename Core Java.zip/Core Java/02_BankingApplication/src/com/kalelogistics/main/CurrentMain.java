package com.kalelogistics.main;

import com.kalelogistics.main.domain.Current;

public class CurrentMain {

	public static void main(String[] args) {
		Current current = new Current(101, "Test", 5000, 50000);
		System.out.println("1. withdraw = 2000");
		current.withdraw(2000);
		System.out.println("balance = " + current.getBalance()); // 3000
		System.out.println("overdraft balance = " + current.getOverdraftBalance()); // 50000

		System.out.println("------------------------------------------------------------");

		System.out.println("2. withdraw = 10000");
		current.withdraw(10000);
		System.out.println("balance = " + current.getBalance()); // 0
		System.out.println("overdraft balance = " + current.getOverdraftBalance()); // 43000

		System.out.println("------------------------------------------------------------");

		System.out.println("3. withdraw = 5000");
		current.withdraw(5000);
		System.out.println("balance = " + current.getBalance()); // 0
		System.out.println("overdraft balance = " + current.getOverdraftBalance()); // 38000

		System.out.println("------------------------------------------------------------");

		System.out.println("4. deposit = 5000");
		current.deposit(5000);
		System.out.println("balance = " + current.getBalance()); // 0
		System.out.println("overdraft balance = " + current.getOverdraftBalance()); // 43000

		System.out.println("------------------------------------------------------------");

		System.out.println("5. deposit = 20000");
		current.deposit(20000);
		System.out.println("balance = " + current.getBalance()); // 13000
		System.out.println("overdraft balance = " + current.getOverdraftBalance()); // 50000

		System.out.println("------------------------------------------------------------");

		System.out.println("6. deposit = 5000");
		current.deposit(5000);
		System.out.println("balance = " + current.getBalance()); // 18000
		System.out.println("overdraft balance = " + current.getOverdraftBalance()); // 50000

	}

}
