package com.kalelogistics.main;

import java.util.Scanner;

import com.kalelogistics.main.domain.Account;

public class AccountMainV3 {
	public static void main(String[] args) {
		// Accept account details = account number,name, balance from user and store
		// into Account object
		// Display account details = account number,name,balance
		Scanner scanner = new Scanner(System.in);
		String continueChoice = "";
		System.out.println("Enter account number");
		long accountNumber = scanner.nextLong();

		scanner.nextLine();

		System.out.println("Enter name");
		String name = scanner.nextLine();

		System.out.println("Enter balance");
		double balance = scanner.nextDouble();

		Account account = new Account(accountNumber, name, balance);

		System.out.println("Account Number = " + account.getAccountNumber());
		System.out.println("Name = " + account.getName());
		System.out.println("Balance = " + account.getBalance());
		System.out.println();

		do {
			System.out.println("Menu");
			System.out.println("1. Withdraw");
			System.out.println("2. Deposit");
			System.out.println("3. Check Balance");
			System.out.println("Enter your choice");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter amount to withdraw");
				double amount = scanner.nextDouble();
				boolean status = account.withdraw(amount);
				if (status) {
					System.out.println("Withdraw Transaction Successfull");
				} else {
					System.out.println("Withdraw Transaction Failed");
				}
				break;
			case 2:
				System.out.println("Enter amount to withdraw");
				amount = scanner.nextDouble();
				status = account.deposit(amount);
				if (status) {
					System.out.println("Deposit Transaction Successfull");
				} else {
					System.out.println("Deposit Transaction Failed");
				}
				break;
			case 3:
				System.out.println("Balance = " + account.getBalance());
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue?");
			continueChoice = scanner.next();
		} while (continueChoice.equals("yes"));
		System.out.println("Thank you");

		scanner.close();

	}
}
