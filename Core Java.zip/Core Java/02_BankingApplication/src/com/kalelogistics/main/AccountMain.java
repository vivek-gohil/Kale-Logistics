package com.kalelogistics.main;

import com.kalelogistics.main.domain.Account;

public class AccountMain {
	public static void main(String[] args) {
		// Creating Account class object
		Account account = new Account(101,"Suman Banik",500000);
		// account.accountNumber = 101;
//		account.setAccountNumber(101);
//		account.setName("Suman Banik");
//		account.setBalance(500000);

		System.out.println("-----------account --------------");

		System.out.println(account.getAccountNumber());
		System.out.println(account.getName());
		System.out.println(account.getBalance());

		System.out.println("-------------------------");
		
		Account bhavyaAccount = new Account();
		bhavyaAccount.setAccountNumber(102);
		bhavyaAccount.setName("Bhavya");
		bhavyaAccount.setBalance(9000000);

		System.out.println("-----------bhavyaAccount--------------");
		System.out.println(bhavyaAccount.getAccountNumber());
		System.out.println(bhavyaAccount.getName());
		System.out.println(bhavyaAccount.getBalance());
		
		System.out.println("-------------------------");
		account.setName("New Name");
				
	}
}
