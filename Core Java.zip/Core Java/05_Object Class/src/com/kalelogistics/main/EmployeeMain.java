package com.kalelogistics.main;

import com.kalelogistics.main.domain.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		Employee employee = new Employee(101, "Smit", 100000);

//		System.out.println(employee.getEmployeeId());
//		System.out.println(employee.getName());
//		System.out.println(employee.getSalary());

		System.out.println(employee.toString());

		String message1 = new String("Hi");
		String message2 = new String("Hi");

		if (message1.equals(message2)) {
			System.out.println("its same");
		} else {
			System.out.println("its different");
		}

		System.out.println("-------------------------------------------");

		Employee employee1 = new Employee(102, "Suman", 100000);
		Employee employee2 = new Employee(102, "Suman", 100000);

		System.out.println("employee1 hashcode = " + employee1.hashCode());
		System.out.println("employee1 hashcode = " + employee2.hashCode());

		if (employee1.equals(employee2)) {
			System.out.println("its same");
		} else {
			System.out.println("its different");
		}
		
		System.out.println("------------------------------------------");
		
		
		
		

	}
}
