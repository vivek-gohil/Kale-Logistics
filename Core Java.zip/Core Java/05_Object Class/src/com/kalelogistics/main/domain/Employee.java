package com.kalelogistics.main.domain;

import java.util.Objects;

//Object class is a root class - base class of every class
public class Employee extends Object {
	private int employeeId;
	private String name;
	private double salary;

	public Employee() {
		System.out.println("Default constructor of Employee");
	}

	public Employee(int employeeId, String name, double salary) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.salary = salary;
		System.out.println("Overloaded constructor of Employee");
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public int hashCode() {
		System.out.println("hashcode() called");
		// return employeeId + name.hashCode() + (int) salary;
		return Objects.hash(employeeId, name, salary);
	}

	// Compare values
	@Override
	public boolean equals(Object obj) {
		System.out.println("equals() called");
		Employee e = (Employee) obj;
		if (this.employeeId == e.employeeId && this.name.equals(e.name) && this.salary == e.salary) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		System.out.println("toString() called");
		return "employeeId = " + employeeId + " name = " + name + " salary = " + salary;
	}

}
