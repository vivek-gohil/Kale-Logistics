package com.kalelogistics.main;

import java.util.List;

import com.kalelogistics.main.domain.Employee;
import com.kalelogistics.main.service.EmployeeService;

public class EmployeeCRUDMainV2 {
	public static void main(String[] args) {
		EmployeeService employeeService = new EmployeeService();

		Employee employee = new Employee(0, "Atharva", 90000);

		//employeeService.addNewEmployee(employee);

		List<Employee> allEmployee = employeeService.selectAllEmployees();

		for (Employee e : allEmployee) {
			System.out.println(e);
		}
	}
}
