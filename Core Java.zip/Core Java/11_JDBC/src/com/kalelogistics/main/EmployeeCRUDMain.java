package com.kalelogistics.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmployeeCRUDMain {
	public static void deleteEmployee(int employeeId) {
		String url = "jdbc:oracle:thin:@localhost:1521/FREEPDB1";
		String username = "springtraining";
		String password = "springtraining";
		String driverClass = "oracle.jdbc.driver.OracleDriver";

		String deleteEmployee = "DELETE FROM employee_details WHERE employee_id=?";

		// Connect database
		Connection connection = null;
		// Write/Store and execute SQL Query
		PreparedStatement preparedStatement = null;

		try {
			// 1. Load Driver
			Class.forName(driverClass);
			System.out.println("Driver Loaded Successfully!!");

			// 2. Connect Database
			connection = DriverManager.getConnection(url, username, password);
			if (connection != null) {
				System.out.println("Connection successfull");
				preparedStatement = connection.prepareStatement(deleteEmployee);
				preparedStatement.setInt(1, employeeId);

				int numberOfRowsDeleted = preparedStatement.executeUpdate();
				System.out.println(numberOfRowsDeleted + " employee deleted");
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Failed to connect database");
			System.out.println(e.getMessage());
		} finally {
			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					System.out.println("Failed to close connection");
				}
		}
	}

	public static void updateEmployee(int employeeId, String name, double salary) {
		String url = "jdbc:oracle:thin:@localhost:1521/FREEPDB1";
		String username = "springtraining";
		String password = "springtraining";
		String driverClass = "oracle.jdbc.driver.OracleDriver";

		String updateEmployee = "UPDATE employee_details SET name=?,salary=? WHERE employee_id=?";

		// Connect database
		Connection connection = null;
		// Write/Store and execute SQL Query
		PreparedStatement preparedStatement = null;

		try {
			// 1. Load Driver
			Class.forName(driverClass);
			System.out.println("Driver Loaded Successfully!!");

			// 2. Connect Database
			connection = DriverManager.getConnection(url, username, password);
			if (connection != null) {
				System.out.println("Connection successfull");
				preparedStatement = connection.prepareStatement(updateEmployee);
				preparedStatement.setString(1, name);
				preparedStatement.setDouble(2, salary);
				preparedStatement.setInt(3, employeeId);

				int numberOfRowsUpdated = preparedStatement.executeUpdate();
				System.out.println(numberOfRowsUpdated + " employee updated");
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Failed to connect database");
			System.out.println(e.getMessage());
		} finally {
			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					System.out.println("Failed to close connection");
				}
		}
	}

	public static void addNewEmployee(String name, double salary) {
		String url = "jdbc:oracle:thin:@localhost:1521/FREEPDB1";
		String username = "springtraining";
		String password = "springtraining";
		String driverClass = "oracle.jdbc.driver.OracleDriver";

		String addNewEmployee = "INSERT INTO employee_details(name,salary) VALUES(?,?)";

		// Connect database
		Connection connection = null;
		// Write/Store and execute SQL Query
		PreparedStatement preparedStatement = null;

		try {
			// 1. Load Driver
			Class.forName(driverClass);
			System.out.println("Driver Loaded Successfully!!");

			// 2. Connect Database
			connection = DriverManager.getConnection(url, username, password);
			if (connection != null) {
				System.out.println("Connection successfull");
				preparedStatement = connection.prepareStatement(addNewEmployee);
				preparedStatement.setString(1, name);
				preparedStatement.setDouble(2, salary);

				int numberOfRowsInserted = preparedStatement.executeUpdate();
				System.out.println(numberOfRowsInserted + " new employee added");
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Failed to connect database");
			System.out.println(e.getMessage());
		} finally {
			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					System.out.println("Failed to close connection");
				}
		}
	}

	public static void selectOneEmployee(int employeeId) {
		String url = "jdbc:oracle:thin:@localhost:1521/FREEPDB1";
		String username = "springtraining";
		String password = "springtraining";
		String driverClass = "oracle.jdbc.driver.OracleDriver";

		String selectOneEmployee = "SELECT * FROM employee_details where employee_id=?";

		// Connect database
		Connection connection = null;
		// Write/Store and execute SQL Query
		PreparedStatement preparedStatement = null;
		// Store Data retrived
		ResultSet resultSet = null;

		try {
			// 1. Load Driver
			Class.forName(driverClass);
			System.out.println("Driver Loaded Successfully!!");

			// 2. Connect Database
			connection = DriverManager.getConnection(url, username, password);
			if (connection != null) {
				System.out.println("Connection successfull");
				preparedStatement = connection.prepareStatement(selectOneEmployee);
				preparedStatement.setInt(1, employeeId);

				resultSet = preparedStatement.executeQuery();

				while (resultSet.next()) {
					System.out.println(resultSet.getInt("employee_id"));
					System.out.println(resultSet.getString("name"));
					System.out.println(resultSet.getDouble("salary"));

					System.out.println();
				}
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Failed to connect database");
			System.out.println(e.getMessage());
		} finally {
			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					System.out.println("Failed to close connection");
				}
		}
	}

	public static void selectAllEmployees() {
		String url = "jdbc:oracle:thin:@localhost:1521/FREEPDB1";
		String username = "springtraining";
		String password = "springtraining";
		String driverClass = "oracle.jdbc.driver.OracleDriver";

		String selectAllEmployees = "SELECT * FROM employee_details";

		// Connect database
		Connection connection = null;
		// Write/Store and execute SQL Query
		PreparedStatement preparedStatement = null;
		// Store Data retrived
		ResultSet resultSet = null;

		try {
			// 1. Load Driver
			Class.forName(driverClass);
			System.out.println("Driver Loaded Successfully!!");

			// 2. Connect Database
			connection = DriverManager.getConnection(url, username, password);
			if (connection != null) {
				System.out.println("Connection successfull");
				preparedStatement = connection.prepareStatement(selectAllEmployees);
				resultSet = preparedStatement.executeQuery();

				while (resultSet.next()) {
					System.out.println(resultSet.getInt("employee_id"));
					System.out.println(resultSet.getString("name"));
					System.out.println(resultSet.getDouble("salary"));

					System.out.println();
				}
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Failed to connect database");
			System.out.println(e.getMessage());
		} finally {
			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					System.out.println("Failed to close connection");
				}
		}
	}

	public static void main(String[] args) {
		// selectAllEmployees();
		// selectOneEmployee(1);
		// addNewEmployee("Rajalakshmi P", 90000);
		// updateEmployee(1, "Atharva", 100000);
		deleteEmployee(1);
		System.out.println();
		selectAllEmployees();
	}
}
