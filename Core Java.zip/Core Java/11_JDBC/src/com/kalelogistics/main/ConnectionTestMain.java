package com.kalelogistics.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionTestMain {

	public static void main(String[] args) {
		System.out.println("main start");
		Connection connection = null;
		try {
			// 1. Load Driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Loaded Successfully!!");

			// 2. Connect Database
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/FREEPDB1", "springtraining",
					"springtraining");
			if (connection != null)
				System.out.println("Connection successfull");

		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Failed to connect database");
			System.out.println(e.getMessage());
		} finally {
			if (connection != null)
				try {
					connection.close();
				} catch (SQLException e) {
					System.out.println("Failed to close connection");
				}
		}

		System.out.println("main end");
	}

}
