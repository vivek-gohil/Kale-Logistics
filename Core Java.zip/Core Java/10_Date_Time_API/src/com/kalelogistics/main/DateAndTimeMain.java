package com.kalelogistics.main;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class DateAndTimeMain {
	public static void main(String[] args) {

		LocalDate localDate = LocalDate.now();
		System.out.println("LocalDate = " + localDate);

		LocalDate customLocalDate = LocalDate.of(2004, 12, 5);
		System.out.println("Custom LocalDate = " + customLocalDate);

		customLocalDate = customLocalDate.plusDays(5);
		System.out.println("Custom LocalDate + 5 days = " + customLocalDate);

		customLocalDate = customLocalDate.plusYears(1);
		System.out.println("Custom LocalDate + 1 year = " + customLocalDate);

		customLocalDate = customLocalDate.minusDays(2);
		System.out.println("Custom LocalDate - 2 days = " + customLocalDate);

		LocalTime localTime = LocalTime.now();
		System.out.println("LocalTime = " + localTime);

		LocalTime customLocalTime = LocalTime.of(15, 30, 5);
		System.out.println("Custom LocalTime = " + customLocalTime);

		customLocalTime = customLocalTime.plusHours(1);
		System.out.println("Custom LocalTime + 1 hour = " + customLocalTime);

		LocalDateTime localDateTime = LocalDateTime.now();
		System.out.println("LocalDateTime = " + localDateTime);

		LocalDateTime customLocalDateTime = LocalDateTime.of(customLocalDate, customLocalTime);
		System.out.println("Custom LocalDateTime = " + customLocalDateTime);
		

	}
}
