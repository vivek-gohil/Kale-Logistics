package com.kalelogistics.main;

import java.io.File;

import com.kalelogistics.main.util.PrintMetadataUtil;

public class PrintMetadataUtilMain {
	public static void main(String[] args) {
		String path = "F:\\Training\\Kale Logistics\\Core Java\\Star.txt";
		File file = new File(path);

		PrintMetadataUtil printMetadataUtil = new PrintMetadataUtil();
		printMetadataUtil.printMetadata(file);

	}
}
