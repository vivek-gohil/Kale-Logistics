package com.kalelogistics.main;

import java.io.File;

import com.kalelogistics.main.util.FileInputStreamUtil;

public class InputStreamMain {
	public static void main(String[] args) {
		String path = "F:\\Training\\Kale Logistics\\Core Java\\Star.txt";
		File file = new File(path);
		FileInputStreamUtil fileInputStreamUtil = new FileInputStreamUtil(file);
		fileInputStreamUtil.readFile();
	}
}
