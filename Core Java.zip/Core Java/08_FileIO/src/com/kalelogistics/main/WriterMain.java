package com.kalelogistics.main;

import java.io.File;

import com.kalelogistics.main.util.FileWriterUtil;

public class WriterMain {
	public static void main(String[] args) {
		String path = "F:\\Training\\Kale Logistics\\Core Java\\KaleLogistics.txt";
		File file = new File(path);
		String data = "Hello .. We are testing!!";
		FileWriterUtil fileWriterUtil = new FileWriterUtil(file, data);
		fileWriterUtil.writeFile();
		System.out.println("Check your file");
	}
}
