package com.kalelogistics.main;

import java.io.File;

import com.kalelogistics.main.util.CopyUtil;
import com.kalelogistics.main.util.FileWriterUtil;

public class CopyMain {
	public static void main(String[] args) {
		String path = "F:\\Training\\Kale Logistics\\Core Java\\user.txt";
		File file = new File(path);

		CopyUtil copyUtil = new CopyUtil(file);
		String data = copyUtil.readFile();
		System.out.println("Data from file");
		System.out.println(data);
		System.out.println("Starting Copy operation");

		path = "F:\\Training\\Kale Logistics\\Core Java\\copyfile.txt";
		file = new File(path);
		FileWriterUtil fileWriterUtil = new FileWriterUtil(file, data);
		fileWriterUtil.writeFile();
		System.out.println("File copied successfully!!");
	}
}
