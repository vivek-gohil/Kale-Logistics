package com.kalelogistics.main.util;

import java.io.File;
import java.util.Date;

public class PrintMetadataUtil {
	public void printMetadata(File file) {
		if (file != null && file.exists()) {
			System.out.println("File Name :: " + file.getName());
			System.out.println("File Path :: " + file.getAbsolutePath());
			System.out.println("File Size :: " + file.length() + " bytes");
			System.out.println("Can read :: " + file.canRead());
			System.out.println("Can write :: " + file.canWrite());
			System.out.println("Can execute :: " + file.canExecute());
			System.out.println("Is Hidden :: " + file.isHidden());
			System.out.println("Is Directory :: " + file.isDirectory());
			System.out.println("Is File :: " + file.isFile());

			Date modifiedDate = new Date(file.lastModified());
			System.out.println("Last Modified Date :: " + modifiedDate);
		} else {
			System.out.println("Invalid File Location");
		}
	}
}
