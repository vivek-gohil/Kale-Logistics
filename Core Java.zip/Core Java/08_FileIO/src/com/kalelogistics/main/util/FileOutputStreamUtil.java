package com.kalelogistics.main.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class FileOutputStreamUtil {
	private OutputStream outputStream;
	private byte[] byteData;

	public FileOutputStreamUtil(File file, String data) {
		try {
			outputStream = new FileOutputStream(file);
			byteData = data.getBytes();
		} catch (IOException e) {
			System.out.println("Failed to write file");
		}
	}

	public void writeFile() {
		try {
			outputStream.write(byteData);
		} catch (IOException e) {
			System.out.println("Failed to write file");
		} finally {
			if (outputStream != null) {
				try {
					outputStream.close();
					outputStream = null;
				} catch (IOException e) {
					System.out.println("Failed to close writer");
				}
			}
		}
	}
}
