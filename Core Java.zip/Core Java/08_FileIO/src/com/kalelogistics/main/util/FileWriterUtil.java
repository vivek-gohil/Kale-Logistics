package com.kalelogistics.main.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class FileWriterUtil {
	private Writer writer;
	private char[] charData;

	public FileWriterUtil(File file, String data) {
		try {
			writer = new FileWriter(file);
			charData = data.toCharArray();
		} catch (IOException e) {
			System.out.println("Failed to write file");
		}
	}

	public void writeFile() {
		try {
			writer.write(charData);
		} catch (IOException e) {
			System.out.println("Failed to write file");
		} finally {
			if (writer != null) {
				try {
					writer.close();
					writer = null;
				} catch (IOException e) {
					System.out.println("Failed to close writer");
				}
			}
		}
	}

}
