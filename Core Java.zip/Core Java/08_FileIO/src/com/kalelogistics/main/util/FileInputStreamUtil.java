package com.kalelogistics.main.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class FileInputStreamUtil {
	private InputStream inputStream;

	private byte[] data = new byte[1024];

	public FileInputStreamUtil(File file) {
		try {
			inputStream = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			System.out.println("Invalid file path");
		}
	}

	public void readFile() {
		try {
			inputStream.read(data);
			String textData = new String(data);
			System.out.println(textData);
		} catch (IOException e) {
			System.out.println("Failed to read file");
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
					inputStream = null;
				} catch (IOException e) {
					System.out.println("Failed to cloase reader");
				}
			}
		}
	}

}
