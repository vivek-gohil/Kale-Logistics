package com.kalelogistics.main.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

public class CopyUtil {
	private Reader reader;
	private Writer writer;
	private char[] data = new char[1024];
	String textData;

	public CopyUtil(File file) {
		try {
			reader = new FileReader(file);
			writer = new FileWriter("F:\\Training\\Kale Logistics\\Core Java\\copy.txt");
		} catch (FileNotFoundException e) {
			System.out.println("Invalid file path to read file");
		} catch (IOException e) {
			System.out.println("Failed to write file");
		}
	}

	public String readFile() {
		try {
			reader.read(data);
			textData = new String(data);
			return textData;
		} catch (IOException e) {
			System.out.println("Failed to read file");
		} finally {
			if (reader != null) {
				try {
					reader.close();
					reader = null;
				} catch (IOException e) {
					System.out.println("Failed to cloase reader");
				}
			}
		}
		return "";
	}

	public void writeFile(String writeData) {
		try {
			writer.write(writeData.toCharArray());
			writer.flush();
		} catch (IOException e) {
			System.out.println("Failed to write file");
		} finally {
			if (writer != null) {
				try {
					writer.close();
					writer = null;
				} catch (IOException e) {
					System.out.println("Failed to close writer");
				}
			}
		}
	}
}
