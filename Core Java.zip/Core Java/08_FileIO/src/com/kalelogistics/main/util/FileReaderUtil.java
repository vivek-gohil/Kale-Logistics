package com.kalelogistics.main.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class FileReaderUtil {

	// To read file
	private Reader reader;

	// To store data of file
	private char[] data = new char[1024];

	public FileReaderUtil(File file) {
		// will connect reader with file to do a read operation
		try {
			reader = new FileReader(file);
		} catch (FileNotFoundException e) {
			System.out.println("Invalid file path");
		}
	}

	public void readFile() {
		try {
			reader.read(data);
			String textData = new String(data);
			System.out.println(textData);
		} catch (IOException e) {
			System.out.println("Failed to read file");
		} finally {
			if (reader != null) {
				try {
					reader.close();
					reader = null;
				} catch (IOException e) {
					System.out.println("Failed to cloase reader");
				}
			}
		}
	}

}
